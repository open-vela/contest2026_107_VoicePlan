# 官方要求执行基准

## 赛道定位

VelaPlan 按“手表应用创新”执行，交付形态为 openvela 快应用。项目可以展示 AI 计划生成能力，但不把底层固件移植、板载语音采集、本地大模型推理作为主线。

## 必须满足

- 作品必须围绕 openvela 平台能力展开，不能只做普通网页或普通后端。
- 快应用必须能在官方手表模拟器中运行，最终提供可安装的 RPK 包。
- 演示必须覆盖完整闭环：输入统一目标、选择计划周期、生成计划、腕上执行、健康/天气影响、复盘建议。
- 健康数据必须通过 `service.health` 或模拟器 Mock 数据体现，至少展示心率、血氧、压力对计划的影响。
- AI 主链路使用官方 `@system.velaclaw` 调用设备端 AI Agent，AI 不可用时保留本地规则计划。
- 语音入口使用官方 `@system.record` 采集音频，按参赛者转述的技术答复，经 `@system.file` 和 `@system.fetch` 接入 MiMo 多模态转写。代码已补齐，最终版需完成带密钥的实际验收。
- 作品介绍、源码仓库、演示视频、RPK 包、AI Coding 日志必须能对应同一个作品版本。
- 如使用 MiMo API，密钥只能保存在本机环境变量、本地 `.env` 或设备应用私有配置中，不能进入仓库、RPK、视频或聊天记录；未配置或失败时不能宣称 AI 成功。
- 如做语音唤醒展示，唤醒词必须使用官方要求的 `你好，openvela` 或 `Hello，openvela`。

## 当前状态与风险

- 当前目录位于已初始化的 openvela `.repo` 工作区内。官方 PR #1 为 Open、可合并状态，CLA 检查已通过；仍需维护者合入 `dev-ai-contest-2026`。
- 当前 Codex 原始 rollout 已由仓库内导出器转换为组委会 schema，图片 Base64 被移除、敏感凭证被脱敏，官方 `validate-log.py` 校验为 `ALL OK`。
- `logs/Yjwqj/` 包含 2 个真实 AI Coding 会话；项目 Skills 沉淀和使用说明已写入 `docs/skills/health-aware-watch-planning/SKILL.md` 与作品材料。
- 当前已实现“录音 → MiMo HTTPS 转写 → 文字确认”，仍需真实账号与麦克风联调；不能把自动测试中的模拟响应冒充云端识别结果。详见 `docs/10-mimo-voice.md`。
- 开发板暂时只能作为硬件展示素材；如果强行走底层烧录和移植，时间风险会明显升高。

## 执行原则

1. 先保证模拟器快应用完整、稳定、可录屏。
2. 通过 `@system.velaclaw` 或本地后端接入 MiMo，让 AI 输出结构化计划；演示环境无 Token 时使用本地规则兜底。
3. 最后整理官方提交材料，不在最后一天补仓库、日志和视频。

## 已完成的能力映射

| 官方要求 | 当前实现 | 验证方式 |
| --- | --- | --- |
| openvela 快应用 | `quickapp/hello_quickapp/` | AIoT-IDE 模拟器运行 |
| 图形能力 | 腕上首页、滚动布局、周期/提醒/天气设置、任务执行和复盘 | 模拟器操作 |
| AI 能力 | `@system.velaclaw` + 本地规则兜底 | 代码检查、模拟器生成流程 |
| 多媒体能力 | `@system.record` WAV 录音 | 代码检查、模拟器录音入口 |
| 健康能力 | `service.health` 心率/血氧/压力读取与订阅 | Mock 数据显示及计划生成 |
| 生产包 | `submission/VelaPlan.release.rpk` | `npm run release`、RPK 内容检查 |
